package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.PreferencesManager
import com.example.python.PythonRuntime
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read app_name string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("AI Builder", appName)
    }

    @Test
    fun `verify preferences manager defaults to gpt-oss-120b`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val prefs = PreferencesManager(context)
        assertEquals("openai/gpt-oss-120b", prefs.modelName)
        prefs.groqApiKey = "gsk_test_key_12345"
        assertTrue(prefs.hasValidApiKey())
        assertEquals("gsk_test_key_12345", prefs.groqApiKey)
    }

    @Test
    fun `verify python runtime executes script correctly`() = runBlocking {
        val runtime = PythonRuntime()
        val script = """
            print("Hello from Python in Android!")
            x = "TestValue"
            print("Value is: " + x)
        """.trimIndent()
        val lines = mutableListOf<String>()
        val result = runtime.executeScript("test.py", script) { line ->
            lines.add(line)
        }
        assertEquals(0, result.exitCode)
        assertTrue(result.output.contains("Hello from Python in Android!"))
    }
}
