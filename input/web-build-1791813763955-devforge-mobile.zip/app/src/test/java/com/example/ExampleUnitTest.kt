package com.example

import com.example.data.BuildLogLevel
import com.example.data.BuildPhase
import com.example.data.GeneratedAppSpec
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun verifyBuildPhasesProgress() {
        assertTrue(BuildPhase.IDLE.progress < BuildPhase.THINKING.progress)
        assertTrue(BuildPhase.THINKING.progress < BuildPhase.KOTLIN_COMPILING.progress)
        assertTrue(BuildPhase.KOTLIN_COMPILING.progress < BuildPhase.READY.progress)
        assertEquals(1.0f, BuildPhase.READY.progress, 0.01f)
    }

    @Test
    fun verifyGeneratedAppSpecDefaults() {
        val spec = GeneratedAppSpec(
            title = "Test App",
            description = "App description",
            category = "Инструменты",
            packageName = "com.aistudio.test.app",
            uiType = "TODO",
            features = listOf("Feature 1", "Feature 2"),
            mainKotlinCode = "fun main() {}",
            pythonScript = "print('ok')",
            gradleCode = "plugins {}",
            manifestCode = "<manifest></manifest>"
        )

        assertEquals("Test App", spec.title)
        assertEquals("com.aistudio.test.app", spec.packageName)
        assertEquals("TODO", spec.uiType)
        assertEquals(2, spec.features.size)
    }
}
