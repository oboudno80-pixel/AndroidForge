package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.python.PythonRuntime
import com.example.ui.theme.TerminalBackground
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TerminalText
import com.example.ui.theme.TerminalYellow
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PythonEnvironmentScreen(
    pythonRuntime: PythonRuntime,
    onApplyScriptToBuild: (String) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var selectedScript by remember { mutableStateOf("build_pipeline.py") }
    val scriptsMap = remember { mutableStateMapOf<String, String>().apply { putAll(pythonRuntime.defaultScripts) } }

    var currentCode by remember(selectedScript) {
        mutableStateOf(scriptsMap[selectedScript] ?: "")
    }

    var isRunning by remember { mutableStateOf(false) }
    var executionOutput by remember { mutableStateOf("") }
    var executionTimeMs by remember { mutableStateOf(0L) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surface)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Environment Header
        Surface(
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Code,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Column {
                        Text(
                            text = "Среда Python 3.12 (Embedded Runtime)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Подготовка ресурсов, AST анализ и запуск Gradle конвейера",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Script Selector Tabs
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(listOf("build_pipeline.py", "layout_optimizer.py", "apk_packager.py", "custom.py")) { scriptName ->
                FilterChip(
                    selected = selectedScript == scriptName,
                    onClick = {
                        scriptsMap[selectedScript] = currentCode
                        selectedScript = scriptName
                        currentCode = scriptsMap[scriptName] ?: "# Новый Python скрипт\nprint('Hello from Android Python!')"
                    },
                    label = { Text(scriptName, fontFamily = FontFamily.Monospace, fontSize = 12.sp) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Terminal,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                )
            }
        }

        // Action Toolbar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = {
                    coroutineScope.launch {
                        isRunning = true
                        executionOutput = ""
                        val result = pythonRuntime.executeScript(
                            scriptName = selectedScript,
                            scriptCode = currentCode
                        ) { line ->
                            executionOutput += line + "\n"
                        }
                        executionTimeMs = result.executionTimeMs
                        isRunning = false
                    }
                },
                enabled = !isRunning,
                modifier = Modifier.testTag("run_python_script_button")
            ) {
                if (isRunning) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Выполнение...")
                } else {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Запустить Python")
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = {
                        currentCode = pythonRuntime.defaultScripts[selectedScript] ?: ""
                    }
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Сброс")
                }
                FilledTonalButton(
                    onClick = {
                        onApplyScriptToBuild(currentCode)
                    }
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("В сборщик")
                }
            }
        }

        // Code Editor & Live Console (Split)
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Python Code Editor Box
            Card(
                modifier = Modifier
                    .weight(0.55f)
                    .fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
            ) {
                OutlinedTextField(
                    value = currentCode,
                    onValueChange = {
                        currentCode = it
                        scriptsMap[selectedScript] = it
                    },
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("python_code_editor"),
                    textStyle = MaterialTheme.typography.bodySmall.copy(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    ),
                    placeholder = { Text("Введите Python код...") }
                )
            }

            // Output Console Box
            Card(
                modifier = Modifier
                    .weight(0.45f)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp)),
                colors = CardDefaults.cardColors(containerColor = TerminalBackground)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "STDOUT / ВЫВОД PYTHON",
                            color = TerminalYellow,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        if (executionTimeMs > 0) {
                            Text(
                                text = "Время: ${executionTimeMs}ms",
                                color = TerminalGreen,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .horizontalScroll(rememberScrollState())
                    ) {
                        Text(
                            text = if (executionOutput.isEmpty()) "Нажмите «Запустить Python» для проверки скрипта..." else executionOutput,
                            color = if (executionOutput.isEmpty()) Color.Gray else TerminalText,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}
