package com.example.data

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class BuildLogLevel {
    INFO,
    COMMAND,
    PYTHON,
    KOTLIN,
    GRADLE,
    SUCCESS,
    ERROR,
    THINKING
}

data class BuildLog(
    val id: Long = System.currentTimeMillis() + (0..999).random(),
    val timestamp: String = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date()),
    val level: BuildLogLevel,
    val message: String
)

data class ProjectFile(
    val name: String,
    val path: String,
    val language: String, // "kotlin", "python", "gradle", "xml", "json"
    var content: String
)

enum class BuildPhase(val displayName: String, val progress: Float) {
    IDLE("Ожидание задачи", 0.0f),
    THINKING("Анализ идеи (Groq gpt-oss-120b)", 0.15f),
    PYTHON_GENERATING("Генерация Python скриптов", 0.30f),
    PYTHON_EXECUTING("Выполнение среды Python", 0.45f),
    GRADLE_RESOLVING("Разрешение зависимостей Gradle", 0.60f),
    KOTLIN_COMPILING("Компиляция Kotlin & Compose", 0.75f),
    AAPT_PACKAGING("Линковка ресурсов AAPT2", 0.85f),
    DEX_OPTIMIZING("D8 / R8 оптимизация байткода", 0.92f),
    APK_SIGNING("Подпись и финализация APK", 0.98f),
    READY("APK собран и готов к установке!", 1.0f),
    ERROR("Ошибка при сборке", 0.0f)
}

data class ApkArtifact(
    val fileName: String,
    val filePath: String,
    val fileSizeBytes: Long,
    val fileSizeFormatted: String,
    val sha256: String,
    val packageName: String,
    val versionCode: Int,
    val versionName: String,
    val buildTimeFormatted: String
)

data class GeneratedAppSpec(
    val title: String,
    val description: String,
    val category: String,
    val packageName: String,
    val uiType: String, // "TODO", "CALCULATOR", "HABIT", "SYNTH", "NOTES", "CUSTOM"
    val features: List<String>,
    val mainKotlinCode: String,
    val pythonScript: String,
    val gradleCode: String,
    val manifestCode: String
)
