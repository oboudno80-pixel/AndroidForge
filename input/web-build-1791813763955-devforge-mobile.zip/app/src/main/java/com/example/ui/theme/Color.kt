package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Authentic Google Material 3 - Clean Developer Palette (No neon, no glassmorphism)
val M3BluePrimaryLight = Color(0xFF0B57D0)
val M3BlueOnPrimaryLight = Color(0xFFFFFFFF)
val M3BluePrimaryContainerLight = Color(0xFFD3E3FD)
val M3BlueOnPrimaryContainerLight = Color(0xFF041E49)

val M3BluePrimaryDark = Color(0xFFA8C7FA)
val M3BlueOnPrimaryDark = Color(0xFF062E6F)
val M3BluePrimaryContainerDark = Color(0xFF0842A0)
val M3BlueOnPrimaryContainerDark = Color(0xFFD3E3FD)

val M3TealSecondaryLight = Color(0xFF006A6A)
val M3TealOnSecondaryLight = Color(0xFFFFFFFF)
val M3TealSecondaryContainerLight = Color(0xFF6FF7F6)
val M3TealOnSecondaryContainerLight = Color(0xFF002020)

val M3TealSecondaryDark = Color(0xFF4DDAD9)
val M3TealOnSecondaryDark = Color(0xFF003737)
val M3TealSecondaryContainerDark = Color(0xFF004F4F)
val M3TealOnSecondaryContainerDark = Color(0xFF6FF7F6)

val M3CoralTertiaryLight = Color(0xFF984061)
val M3CoralTertiaryDark = Color(0xFFFFB0C9)

val M3SurfaceLight = Color(0xFFF8F9FA)
val M3SurfaceDark = Color(0xFF131314)
val M3SurfaceVariantLight = Color(0xFFE1E2EC)
val M3SurfaceVariantDark = Color(0xFF44474F)

val M3SurfaceContainerLight = Color(0xFFEDEEF2)
val M3SurfaceContainerDark = Color(0xFF1E1F22)
val M3SurfaceContainerHighLight = Color(0xFFE2E3E8)
val M3SurfaceContainerHighDark = Color(0xFF282A2E)

val M3OutlineLight = Color(0xFF74777F)
val M3OutlineDark = Color(0xFF8E9099)

// Terminal specific developer colors
val TerminalBackground = Color(0xFF181A1F)
val TerminalText = Color(0xFFE6EDF3)
val TerminalGreen = Color(0xFF34D399)
val TerminalBlue = Color(0xFF60A5FA)
val TerminalYellow = Color(0xFFFBBF24)
val TerminalPurple = Color(0xFFC084FC)
val TerminalRed = Color(0xFFF87171)
