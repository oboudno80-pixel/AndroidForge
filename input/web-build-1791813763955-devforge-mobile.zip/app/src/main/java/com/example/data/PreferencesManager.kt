package com.example.data

import android.content.Context
import android.content.SharedPreferences

class PreferencesManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("ai_builder_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_GROQ_API_KEY = "groq_api_key"
        private const val KEY_MODEL_NAME = "groq_model_name"
        private const val DEFAULT_MODEL = "openai/gpt-oss-120b"
        private const val KEY_FIRST_LAUNCH = "first_launch_done"
    }

    var groqApiKey: String
        get() = prefs.getString(KEY_GROQ_API_KEY, "") ?: ""
        set(value) = prefs.edit().putString(KEY_GROQ_API_KEY, value.trim()).apply()

    var modelName: String
        get() = prefs.getString(KEY_MODEL_NAME, DEFAULT_MODEL) ?: DEFAULT_MODEL
        set(value) = prefs.edit().putString(KEY_MODEL_NAME, value.trim()).apply()

    var isFirstLaunchDone: Boolean
        get() = prefs.getBoolean(KEY_FIRST_LAUNCH, false)
        set(value) = prefs.edit().putBoolean(KEY_FIRST_LAUNCH, value).apply()

    fun hasValidApiKey(): Boolean = groqApiKey.isNotBlank()
}
