package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GeneratedAppSpec

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppPreviewScreen(
    spec: GeneratedAppSpec?,
    onDownloadApk: () -> Unit,
    onBackToConsole: () -> Unit
) {
    if (spec == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.PhoneAndroid,
                    contentDescription = null,
                    modifier = Modifier.size(56.dp),
                    tint = MaterialTheme.colorScheme.outline
                )
                Text(
                    text = "Приложение еще не собрано",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Запустите автоматическую сборку проекта на вкладке «Сборка», чтобы протестировать его здесь в реальном времени.",
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Button(
                    onClick = onBackToConsole,
                    modifier = Modifier.testTag("preview_back_to_build_btn")
                ) {
                    Text("Перейти к сборке")
                }
            }
        }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surface)
    ) {
        // Emulator Top Banner
        Surface(
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        color = MaterialTheme.colorScheme.primary,
                        shape = CircleShape,
                        modifier = Modifier.size(10.dp)
                    ) {}
                    Text(
                        text = "LIVE PREVIEW: ${spec.title}",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                FilledTonalButton(
                    onClick = onDownloadApk,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.testTag("preview_download_apk_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Скачать APK", fontSize = 12.sp)
                }
            }
        }

        // Live Simulated App Content Container
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(8.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(MaterialTheme.colorScheme.background)
        ) {
            when (spec.uiType) {
                "CALCULATOR" -> CalculatorArchetypeScreen(spec)
                "HABIT" -> HabitTrackerArchetypeScreen(spec)
                "SYNTH" -> RetroSynthArchetypeScreen(spec)
                "NOTES" -> NotesArchetypeScreen(spec)
                else -> TodoArchetypeScreen(spec)
            }
        }
    }
}

// 1. TODO / TASK ARCHETYPE
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TodoArchetypeScreen(spec: GeneratedAppSpec) {
    var taskInput by remember { mutableStateOf("") }
    val tasks = remember {
        mutableStateListOf(
            "Подготовить архитектуру проекта" to true,
            "Сгенерировать код Jetpack Compose" to true,
            "Скомпилировать Dalvik DEX байткод" to true,
            "Протестировать приложение на устройстве" to false
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(spec.title) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = taskInput,
                    onValueChange = { taskInput = it },
                    placeholder = { Text("Новая задача...") },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("preview_todo_input"),
                    singleLine = true
                )
                Button(
                    onClick = {
                        if (taskInput.isNotBlank()) {
                            tasks.add(0, taskInput.trim() to false)
                            taskInput = ""
                        }
                    },
                    modifier = Modifier.testTag("preview_todo_add_btn")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Добавить")
                }
            }

            Text(
                text = "Всего задач: ${tasks.size} (Выполнено: ${tasks.count { it.second }})",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(tasks.indices.toList()) { index ->
                    val (taskText, isDone) = tasks[index]
                    ElevatedCard(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            tasks[index] = taskText to !isDone
                        }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Checkbox(
                                    checked = isDone,
                                    onCheckedChange = { tasks[index] = taskText to it }
                                )
                                Text(
                                    text = taskText,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = if (isDone) FontWeight.Normal else FontWeight.Medium
                                )
                            }
                            IconButton(onClick = { tasks.removeAt(index) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Удалить", tint = Color.Gray)
                            }
                        }
                    }
                }
            }
        }
    }
}

// 2. CALCULATOR ARCHETYPE
@Composable
fun CalculatorArchetypeScreen(spec: GeneratedAppSpec) {
    var display by remember { mutableStateOf("0") }
    var expression by remember { mutableStateOf("") }

    fun onKeyClick(key: String) {
        when (key) {
            "C" -> {
                display = "0"
                expression = ""
            }
            "=" -> {
                try {
                    val exp = if (expression.isNotEmpty()) expression + display else display
                    val clean = exp.replace("×", "*").replace("÷", "/")
                    val res = evaluateSimpleMath(clean)
                    display = res
                    expression = ""
                } catch (e: Exception) {
                    display = "Ошибка"
                }
            }
            "+", "-", "×", "÷" -> {
                expression = "$display $key "
                display = "0"
            }
            else -> {
                if (display == "0") display = key else display += key
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Display
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = expression,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = display,
                    fontSize = 36.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }

        // Keypad Grid
        val keys = listOf(
            listOf("C", "÷", "×", "⌫"),
            listOf("7", "8", "9", "-"),
            listOf("4", "5", "6", "+"),
            listOf("1", "2", "3", "="),
            listOf("0", ".", "±", "")
        )

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            for (row in keys) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    for (k in row) {
                        if (k.isEmpty()) {
                            Spacer(modifier = Modifier.weight(1f))
                            continue
                        }
                        val isOp = k in listOf("+", "-", "×", "÷", "=")
                        val isC = k == "C"
                        Button(
                            onClick = {
                                if (k == "⌫") {
                                    display = if (display.length > 1) display.dropLast(1) else "0"
                                } else if (k == "±") {
                                    display = if (display.startsWith("-")) display.drop(1) else "-$display"
                                } else {
                                    onKeyClick(k)
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(56.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = when {
                                    isOp -> MaterialTheme.colorScheme.primary
                                    isC -> MaterialTheme.colorScheme.errorContainer
                                    else -> MaterialTheme.colorScheme.surfaceContainerHigh
                                },
                                contentColor = when {
                                    isOp -> MaterialTheme.colorScheme.onPrimary
                                    isC -> MaterialTheme.colorScheme.onErrorContainer
                                    else -> MaterialTheme.colorScheme.onSurface
                                }
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(text = k, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// 3. HABIT TRACKER ARCHETYPE
@Composable
fun HabitTrackerArchetypeScreen(spec: GeneratedAppSpec) {
    val habits = remember {
        mutableStateListOf(
            "Утренняя зарядка (15 мин)" to 5,
            "Выпить 2 литра воды" to 7,
            "Изучить 1 урок Kotlin" to 3,
            "Медитация перед сном" to 4
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Серия привычек",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Text(
                        text = "Отличный темп! 4 активных привычки",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
                Icon(
                    imageVector = Icons.Default.LocalFireDepartment,
                    contentDescription = null,
                    tint = Color(0xFFE8710A),
                    modifier = Modifier.size(36.dp)
                )
            }
        }

        Text(
            text = "Ваши привычки",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(habits.indices.toList()) { i ->
                val (name, streak) = habits[i]
                OutlinedCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = name, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Серия: $streak дней подряд 🔥",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Button(
                            onClick = {
                                habits[i] = name to (streak + 1)
                            }
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Отметить")
                        }
                    }
                }
            }
        }
    }
}

// 4. RETRO SYNTH ARCHETYPE
@Composable
fun RetroSynthArchetypeScreen(spec: GeneratedAppSpec) {
    var activeNote by remember { mutableStateOf("Ready") }
    var waveform by remember { mutableStateOf("Sawtooth") }

    val notes = listOf("C4", "D4", "E4", "F4", "G4", "A4", "B4", "C5")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(text = "Активная нота: $activeNote", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                Text(text = "Форма волны: $waveform | Freq: 440 Hz", style = MaterialTheme.typography.labelMedium)
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            listOf("Sine", "Sawtooth", "Square").forEach { wf ->
                FilterChip(
                    selected = waveform == wf,
                    onClick = { waveform = wf },
                    label = { Text(wf) }
                )
            }
        }

        Text(text = "Клавиатура синтезатора", fontWeight = FontWeight.Bold)

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            notes.forEach { note ->
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .height(140.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { activeNote = note },
                    color = if (activeNote == note) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                    tonalElevation = 4.dp
                ) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.BottomCenter
                    ) {
                        Text(
                            text = note,
                            modifier = Modifier.padding(bottom = 12.dp),
                            fontWeight = FontWeight.Bold,
                            color = if (activeNote == note) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}

// 5. NOTES ARCHETYPE
@Composable
fun NotesArchetypeScreen(spec: GeneratedAppSpec) {
    val sampleNotes = remember {
        mutableStateListOf(
            "Архитектура проекта" to "Использовать Jetpack Compose, Kotlin Gradle DSL и Python pre-build скрипты.",
            "Планы на релиз" to "Собрать APK, проверить SHA256 и распространить среди команды тестировщиков.",
            "Идеи для фич" to "Добавить поддержку офлайн моделей и экспорт проектов в ZIP архив."
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "Заметки и идеи",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(sampleNotes.indices.toList()) { idx ->
                val (title, text) = sampleNotes[idx]
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHigh)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(text = title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = text, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}

private fun evaluateSimpleMath(expr: String): String {
    val clean = expr.trim()
    val parts = clean.split(" ")
    if (parts.size == 3) {
        val a = parts[0].toDoubleOrNull() ?: 0.0
        val op = parts[1]
        val b = parts[2].toDoubleOrNull() ?: 0.0
        val result = when (op) {
            "+" -> a + b
            "-" -> a - b
            "*" -> a * b
            "/" -> if (b != 0.0) a / b else return "Ошибка"
            else -> a
        }
        return if (result % 1.0 == 0.0) result.toLong().toString() else "%.2f".format(result)
    }
    return clean
}
