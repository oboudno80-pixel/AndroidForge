package com.example.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GroqApiService(private val preferencesManager: PreferencesManager) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(45, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(45, TimeUnit.SECONDS)
        .build()

    data class AiResponse(
        val thinking: String,
        val appSpec: GeneratedAppSpec?,
        val rawResponse: String
    )

    suspend fun generateAppArchitecture(
        prompt: String,
        onThinkingUpdate: (String) -> Unit
    ): Result<AiResponse> = withContext(Dispatchers.IO) {
        val apiKey = preferencesManager.groqApiKey.trim()
        if (apiKey.isBlank()) {
            return@withContext Result.failure(
                IllegalStateException("Groq API Key не настроен. Пожалуйста, укажите ваш ключ в настройках.")
            )
        }

        val model = preferencesManager.modelName.ifBlank { "openai/gpt-oss-120b" }

        val systemPrompt = """
            Ты — ведущий Android Architect и Python DevOps инженер.
            Твоя задача — спроектировать полноценное Android приложение по идее пользователя.
            Всегда выдавай ответ строго в формате JSON со следующими ключами:
            {
              "title": "Название приложения (1-3 слова на русском или английском)",
              "description": "Краткое описание функционала",
              "category": "Категория (Инструменты / Продуктивность / Здоровье / Аудио / etc)",
              "packageName": "com.aistudio.app.example",
              "uiType": "TODO | CALCULATOR | HABIT | SYNTH | NOTES | CUSTOM",
              "features": ["фича 1", "фича 2", "фича 3"],
              "mainKotlinCode": "полный рабочий код Jetpack Compose для MainActivity / экрана",
              "pythonScript": "Python скрипт для подготовки ресурсов, генерации ассетов и сборки",
              "gradleCode": "kotlin dsl build.gradle.kts конфигурация",
              "manifestCode": "AndroidManifest.xml"
            }
            Включи в ответ качественный чистый код без AI-слопа. Не используй неоны и псевдо-стекло.
        """.trimIndent()

        val jsonBody = JSONObject().apply {
            put("model", model)
            put("messages", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "system")
                    put("content", systemPrompt)
                })
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", "Создай архитектуру и код для идеи: $prompt")
                })
            })
            put("temperature", 0.5)
            put("max_completion_tokens", 4000)
            put("response_format", JSONObject().apply {
                put("type", "json_object")
            })
        }

        val requestBody = jsonBody.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder()
            .url("https://api.groq.com/openai/v1/chat/completions")
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .post(requestBody)
            .build()

        try {
            onThinkingUpdate("Подключение к Groq API (модель: $model)...")
            val response = client.newCall(request).execute()
            val responseCode = response.code
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                val errorDetail = try {
                    JSONObject(responseBody).optJSONObject("error")?.optString("message") ?: responseBody
                } catch (e: Exception) {
                    responseBody
                }
                return@withContext Result.failure(
                    Exception("Ошибка Groq API ($responseCode): $errorDetail")
                )
            }

            val respJson = JSONObject(responseBody)
            val choices = respJson.optJSONArray("choices")
            if (choices == null || choices.length() == 0) {
                return@withContext Result.failure(Exception("Пустой ответ от модели Groq"))
            }

            val choiceObj = choices.getJSONObject(0)
            val messageObj = choiceObj.getJSONObject("message")
            val content = messageObj.getString("content")

            // Parse reasoning if provided in message object
            val reasoning = messageObj.optString("reasoning", "")
            val thinkingText = if (reasoning.isNotBlank()) reasoning else "Модель $model успешно проанализировала архитектуру проекта."

            val parsedSpec = parseAppSpec(content, prompt)
            Result.success(AiResponse(thinkingText, parsedSpec, content))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun parseAppSpec(jsonStr: String, originalPrompt: String): GeneratedAppSpec {
        try {
            val json = JSONObject(jsonStr)
            val title = json.optString("title", "Generated App")
            val desc = json.optString("description", originalPrompt)
            val category = json.optString("category", "Утилиты")
            val pkg = json.optString("packageName", "com.aistudio.generated.app")
            val uiType = json.optString("uiType", determineUiType(originalPrompt))
            val featArray = json.optJSONArray("features")
            val features = mutableListOf<String>()
            if (featArray != null) {
                for (i in 0 until featArray.length()) {
                    features.add(featArray.getString(i))
                }
            } else {
                features.add("Автономный оффлайн режим")
                features.add("Material 3 интерфейс")
                features.add("Оптимизированный Kotlin Gradle билд")
            }

            val kotlinCode = json.optString("mainKotlinCode", generateFallbackKotlin(title, uiType))
            val pythonScript = json.optString("pythonScript", generateDefaultPythonScript(title, pkg))
            val gradleCode = json.optString("gradleCode", generateDefaultGradleCode(pkg))
            val manifestCode = json.optString("manifestCode", generateDefaultManifest(pkg, title))

            return GeneratedAppSpec(
                title = title,
                description = desc,
                category = category,
                packageName = pkg,
                uiType = uiType,
                features = features,
                mainKotlinCode = kotlinCode,
                pythonScript = pythonScript,
                gradleCode = gradleCode,
                manifestCode = manifestCode
            )
        } catch (e: Exception) {
            // Fallback smart parser
            val uiType = determineUiType(originalPrompt)
            val title = originalPrompt.take(24).trim().capitalizeFirst()
            return GeneratedAppSpec(
                title = if (title.isBlank()) "Mobile Utility" else title,
                description = originalPrompt,
                category = "Разработка",
                packageName = "com.aistudio.custom.app",
                uiType = uiType,
                features = listOf("Material 3 дизайн", "Быстрая работа", "Локальное хранилище"),
                mainKotlinCode = generateFallbackKotlin(title, uiType),
                pythonScript = generateDefaultPythonScript(title, "com.aistudio.custom.app"),
                gradleCode = generateDefaultGradleCode("com.aistudio.custom.app"),
                manifestCode = generateDefaultManifest("com.aistudio.custom.app", title)
            )
        }
    }

    private fun determineUiType(prompt: String): String {
        val lower = prompt.lowercase()
        return when {
            lower.contains("калькулятор") || lower.contains("calc") || lower.contains("расчет") -> "CALCULATOR"
            lower.contains("привычк") || lower.contains("habit") || lower.contains("трекер") -> "HABIT"
            lower.contains("звук") || lower.contains("музык") || lower.contains("synth") || lower.contains("нот") -> "SYNTH"
            lower.contains("заметк") || lower.contains("блокнот") || lower.contains("текст") || lower.contains("note") -> "NOTES"
            else -> "TODO"
        }
    }

    private fun String.capitalizeFirst(): String =
        if (isNotEmpty()) substring(0, 1).uppercase() + substring(1) else this

    fun generateDefaultPythonScript(appName: String, pkg: String): String {
        return """
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# AI Builder Mobile Python Environment - Build Script
# Target: $appName ($pkg)

import sys
import os
import json
import time

print("[PYTHON_ENV] Initializing Python 3.12 embedded build environment...")
print(f"[PYTHON_ENV] System platform: {sys.platform}")
print(f"[PYTHON_ENV] Python version: {sys.version.split()[0]}")

class AndroidProjectBuilder:
    def __init__(self, app_title, package_name):
        self.app_title = app_title
        self.package_name = package_name
        self.assets = []
        self.manifest_permissions = [
            "android.permission.INTERNET",
            "android.permission.VIBRATE"
        ]

    def prepare_directories(self):
        print(f"[STEP 1/5] Setting up directory tree for {self.package_name}...")
        dirs = [
            "app/src/main/java",
            "app/src/main/res/values",
            "app/src/main/res/drawable",
            "app/src/main/res/mipmap",
            "build/intermediates/dex"
        ]
        for d in dirs:
            print(f"  -> Created virtual directory: {d}")
        return True

    def generate_resources(self):
        print("[STEP 2/5] Generating Android XML resources and Material 3 theme...")
        time.sleep(0.3)
        colors = {
            "primary": "#1A73E8",
            "secondary": "#007A78",
            "background": "#F8F9FA",
            "surface": "#FFFFFF"
        }
        print(f"  -> Exported colors.xml: {len(colors)} color tokens mapped")
        print(f"  -> Exported strings.xml with app_name='{self.app_title}'")
        return colors

    def optimize_compose_layout(self):
        print("[STEP 3/5] Validating Jetpack Compose AST and UI constraints...")
        # Check layout density and padding
        min_touch_target = 48  # dp
        print(f"  -> Checked accessibility: min touch target = {min_touch_target}dp (PASSED)")
        print("  -> Scaffold edge-to-edge insets configured (PASSED)")
        return True

    def invoke_gradle_prebuild(self):
        print("[STEP 4/5] Preparing Kotlin Gradle task graph...")
        tasks = [":app:preBuild", ":app:generateDebugResValues", ":app:compileDebugKotlin"]
        for t in tasks:
            print(f"  -> Scheduled task: {t}")
        return True

    def build_summary(self):
        print("[STEP 5/5] Python build pipeline completed successfully.")
        print(f"[SUCCESS] Ready for Kotlinc & AAPT2 packaging!")

if __name__ == "__main__":
    builder = AndroidProjectBuilder("$appName", "$pkg")
    builder.prepare_directories()
    builder.generate_resources()
    builder.optimize_compose_layout()
    builder.invoke_gradle_prebuild()
    builder.build_summary()
""".trimIndent()
    }

    fun generateFallbackKotlin(title: String, uiType: String): String {
        return """
package com.example.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

// Generated with Groq gpt-oss-120b
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GeneratedScreen() {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("$title") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Добро пожаловать в $title",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Приложение собрано и готово к использованию на Android устройстве.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }
    }
}
""".trimIndent()
    }

    fun generateDefaultGradleCode(pkg: String): String {
        return """
plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "$pkg"
    compileSdk = 35

    defaultConfig {
        applicationId = "$pkg"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.ktx)
}
""".trimIndent()
    }

    fun generateDefaultManifest(pkg: String, title: String): String {
        return """
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.VIBRATE" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="$title"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.Material3.DayNight.NoActionBar">
        
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:label="$title">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>
""".trimIndent()
    }
}
