package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BuildLog
import com.example.data.BuildLogLevel
import com.example.ui.theme.*

@Composable
fun ConsoleView(
    logs: List<BuildLog>,
    onClearLogs: () -> Unit,
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState()
    val clipboardManager = LocalClipboardManager.current
    var autoScroll by remember { mutableStateOf(true) }

    LaunchedEffect(logs.size, autoScroll) {
        if (autoScroll && logs.isNotEmpty()) {
            listState.animateScrollToItem(logs.size - 1)
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(
            containerColor = TerminalBackground
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Console Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF21252B))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Terminal,
                        contentDescription = "Console",
                        tint = TerminalBlue,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "BUILD TERMINAL",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = TerminalText
                    )
                    Surface(
                        color = if (logs.isNotEmpty()) TerminalGreen.copy(alpha = 0.2f) else Color.DarkGray,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "${logs.size} строк",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = if (logs.isNotEmpty()) TerminalGreen else Color.LightGray,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            val allText = logs.joinToString("\n") { "[${it.timestamp}] ${it.level}: ${it.message}" }
                            clipboardManager.setText(AnnotatedString(allText))
                        },
                        modifier = Modifier
                            .size(28.dp)
                            .testTag("copy_logs_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Копировать логи",
                            tint = Color.LightGray,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                    IconButton(
                        onClick = onClearLogs,
                        modifier = Modifier
                            .size(28.dp)
                            .testTag("clear_logs_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Очистить консоль",
                            tint = Color.LightGray,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }

            // Console Logs Stream
            if (logs.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Ожидание запуска задачи...\nНажмите «Собрать APK прямо сейчас» для запуска конвейера.",
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color.Gray
                    )
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    items(logs, key = { it.id }) { log ->
                        LogLineItem(log = log)
                    }
                }
            }
        }
    }
}

@Composable
private fun LogLineItem(log: BuildLog) {
    val (levelColor, tag) = when (log.level) {
        BuildLogLevel.COMMAND -> TerminalBlue to "$"
        BuildLogLevel.PYTHON -> TerminalYellow to "PY"
        BuildLogLevel.KOTLIN -> TerminalPurple to "KT"
        BuildLogLevel.GRADLE -> Color(0xFF38BDF8) to "GRADLE"
        BuildLogLevel.SUCCESS -> TerminalGreen to "SUCCESS"
        BuildLogLevel.ERROR -> TerminalRed to "ERR"
        BuildLogLevel.THINKING -> Color(0xFFF472B6) to "THINK"
        BuildLogLevel.INFO -> Color.LightGray to "INFO"
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = log.timestamp,
            color = Color.DarkGray,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.width(68.dp)
        )
        Text(
            text = "[$tag]",
            color = levelColor,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.width(52.dp)
        )
        Text(
            text = log.message,
            color = when (log.level) {
                BuildLogLevel.COMMAND -> TerminalBlue
                BuildLogLevel.SUCCESS -> TerminalGreen
                BuildLogLevel.ERROR -> TerminalRed
                BuildLogLevel.THINKING -> Color(0xFFE2E8F0)
                else -> TerminalText
            },
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}
