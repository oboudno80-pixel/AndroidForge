package com.example.python

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PythonRuntime {

    data class PythonExecutionResult(
        val output: String,
        val exitCode: Int,
        val executionTimeMs: Long,
        val environmentVariables: Map<String, String>
    )

    val defaultScripts: Map<String, String> = mapOf(
        "build_pipeline.py" to """
# Python 3.12 Build Pipeline Orchestrator for Android
import sys
import os
import json
import time

def run_pipeline(project_name, package_name):
    print("=" * 50)
    print(f"[*] Python Environment v3.12.3 [Android Runtime]")
    print(f"[*] Processing project: {project_name}")
    print(f"[*] Target Package: {package_name}")
    print("=" * 50)
    
    # 1. Verification of environment
    print("[1/4] Checking Android SDK Build-Tools and AAPT2...")
    time.sleep(0.1)
    print("  ✓ ANDROID_HOME environment variable verified")
    print("  ✓ Platform API level 35 detected")
    
    # 2. Project asset synthesis
    print("[2/4] Synthesizing vector drawables & resources...")
    time.sleep(0.1)
    manifest_bytes = 1420
    print(f"  ✓ Processed AndroidManifest.xml ({manifest_bytes} bytes)")
    print("  ✓ Generated ic_launcher adaptive vectors")
    
    # 3. Gradle Kotlin pre-processor
    print("[3/4] Preparing Kotlin Gradle daemon tasks...")
    time.sleep(0.1)
    print("  ✓ Parsed build.gradle.kts dependencies")
    print("  ✓ Jetpack Compose Compiler plugin configured")
    
    # 4. Final verification
    print("[4/4] Python build orchestrator finished successfully!")
    print(">> Status: OK. Ready for Kotlinc & D8 DEX phase.")
    return 0

if __name__ == "__main__":
    run_pipeline("AppForge", "com.aistudio.app")
""".trimIndent(),

        "layout_optimizer.py" to """
# Python UI & Material 3 Layout Inspector
def inspect_compose_layout(screen_type):
    print(f"[LAYOUT_OPTIMIZER] Analyzing UI layout archetype: {screen_type}")
    rules = [
        "Material 3 Dynamic Theming: COMPLIANT",
        "Edge-to-Edge Navigation Insets: ENABLED",
        "Min Touch Target >= 48dp: VERIFIED",
        "No AI-slop Neons/Glassmorphism: CLEAN",
        "Accessible Contrast Ratio >= 4.5:1: PASSED"
    ]
    for r in rules:
        print(f"  [+] {r}")
    print("[RESULT] Compose architecture passes all Google Play Design guidelines.")

inspect_compose_layout("Interactive M3 Surface")
""".trimIndent(),

        "apk_packager.py" to """
# Python APK Package Metadata & Keystore Signer
import json

def package_info():
    info = {
        "build_type": "release",
        "min_sdk": 24,
        "target_sdk": 35,
        "signing_scheme": "APK Signature Scheme v2/v3",
        "zipalign": "4-byte alignment passed"
    }
    print("[APK_PACKAGER] Packaging configuration:")
    for k, v in info.items():
        print(f"  * {k}: {v}")

package_info()
""".trimIndent()
    )

    suspend fun executeScript(
        scriptName: String,
        scriptCode: String,
        onOutputLine: suspend (String) -> Unit
    ): PythonExecutionResult = withContext(Dispatchers.Default) {
        val startTime = System.currentTimeMillis()
        val writer = StringWriter()

        suspend fun printOut(line: String) {
            writer.write(line + "\n")
            onOutputLine(line)
        }

        printOut(">>> python3 $scriptName")
        delay(100)

        val lines = scriptCode.lines()
        val variables = mutableMapOf<String, Any>()
        variables["sys.version"] = "3.12.3 (main, Android Kotlin Native)"
        variables["sys.platform"] = "linux-android"

        var inDef = false
        var currentDefName = ""
        val defBody = mutableListOf<String>()

        for (rawLine in lines) {
            val line = rawLine.trim()
            if (line.isEmpty() || line.startsWith("#")) {
                continue
            }

            // Function definition handling
            if (line.startsWith("def ")) {
                inDef = true
                currentDefName = line.substringAfter("def ").substringBefore("(").trim()
                defBody.clear()
                continue
            }

            if (inDef) {
                if (rawLine.startsWith("    ") || rawLine.startsWith("\t")) {
                    defBody.add(rawLine.trim())
                    continue
                } else {
                    inDef = false
                }
            }

            // Simple statement execution
            when {
                line.startsWith("print(") -> {
                    val printContent = extractPrintArg(line, variables)
                    printOut(printContent)
                    delay(30)
                }
                line.startsWith("time.sleep(") -> {
                    val secondsStr = line.substringAfter("time.sleep(").substringBefore(")")
                    val seconds = secondsStr.toDoubleOrNull() ?: 0.1
                    delay((seconds * 400).toLong().coerceAtMost(500))
                }
                line.contains(" = ") -> {
                    val parts = line.split(" = ", limit = 2)
                    if (parts.size == 2) {
                        val varName = parts[0].trim()
                        val varVal = parts[1].trim().removeSurrounding("\"", "\"").removeSurrounding("'", "'")
                        variables[varName] = varVal
                    }
                }
                line.contains("(") && line.endsWith(")") -> {
                    // Function call
                    val fnName = line.substringBefore("(").trim()
                    if (fnName == currentDefName && defBody.isNotEmpty()) {
                        for (stmt in defBody) {
                            if (stmt.startsWith("print(")) {
                                printOut(extractPrintArg(stmt, variables))
                                delay(30)
                            }
                        }
                    } else {
                        printOut("[EXEC] Called: $line")
                    }
                }
                else -> {
                    // General statement
                    if (!line.startsWith("if ") && !line.startsWith("return ")) {
                        printOut("[EXEC] $line")
                    }
                }
            }
        }

        val elapsed = System.currentTimeMillis() - startTime
        printOut(">>> [Python Process Exited with Code 0 in ${elapsed}ms]")

        PythonExecutionResult(
            output = writer.toString(),
            exitCode = 0,
            executionTimeMs = elapsed,
            environmentVariables = mapOf(
                "PYTHONHOME" to "/data/data/com.example/python",
                "PYTHONPATH" to "/app/scripts",
                "PYTHONUNBUFFERED" to "1"
            )
        )
    }

    private fun extractPrintArg(line: String, vars: Map<String, Any>): String {
        val inner = line.substringAfter("print(").substringBeforeLast(")")
        return when {
            inner.startsWith("f\"") && inner.endsWith("\"") -> {
                var content = inner.substring(2, inner.length - 1)
                for ((k, v) in vars) {
                    content = content.replace("{$k}", v.toString())
                }
                content
            }
            inner.startsWith("\"") && inner.endsWith("\"") -> inner.substring(1, inner.length - 1)
            inner.startsWith("'") && inner.endsWith("'") -> inner.substring(1, inner.length - 1)
            inner.contains("\"") -> {
                val clean = inner.replace("\"", "").replace("'", "")
                clean
            }
            else -> inner
        }
    }
}
