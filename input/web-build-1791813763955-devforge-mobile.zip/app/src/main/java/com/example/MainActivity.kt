package com.example

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MainViewModel
import com.example.ui.components.ApiKeyDialog
import com.example.ui.screens.AppPreviewScreen
import com.example.ui.screens.BuildScreen
import com.example.ui.screens.ProjectFilesScreen
import com.example.ui.screens.PythonEnvironmentScreen
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.flow.collectLatest

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()
            val snackbarHostState = remember { SnackbarHostState() }

            LaunchedEffect(Unit) {
                viewModel.userMessage.collectLatest { msg ->
                    snackbarHostState.showSnackbar(msg)
                }
            }

            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = {
                        TopAppBar(
                            title = {
                                Row(
                                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Handyman,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Text(
                                        text = "AI Builder",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleLarge
                                    )
                                }
                            },
                            actions = {
                                IconButton(
                                    onClick = { viewModel.openApiKeyDialog() },
                                    modifier = Modifier.testTag("top_bar_key_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.VpnKey,
                                        contentDescription = "Groq API Ключ",
                                        tint = if (uiState.groqApiKey.isNotBlank()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                                    )
                                }
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MaterialTheme.colorScheme.surfaceContainer,
                                titleContentColor = MaterialTheme.colorScheme.onSurface
                            )
                        )
                    },
                    bottomBar = {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surfaceContainer,
                            windowInsets = WindowInsets.navigationBars
                        ) {
                            NavigationBarItem(
                                selected = uiState.selectedTab == 0,
                                onClick = { viewModel.setSelectedTab(0) },
                                icon = {
                                    Icon(
                                        if (uiState.selectedTab == 0) Icons.Default.RocketLaunch else Icons.Default.Rocket,
                                        contentDescription = "Сборка"
                                    )
                                },
                                label = { Text("Сборка") },
                                modifier = Modifier.testTag("nav_tab_build")
                            )

                            NavigationBarItem(
                                selected = uiState.selectedTab == 1,
                                onClick = { viewModel.setSelectedTab(1) },
                                icon = {
                                    Icon(
                                        Icons.Default.Terminal,
                                        contentDescription = "Python"
                                    )
                                },
                                label = { Text("Python") },
                                modifier = Modifier.testTag("nav_tab_python")
                            )

                            NavigationBarItem(
                                selected = uiState.selectedTab == 2,
                                onClick = { viewModel.setSelectedTab(2) },
                                icon = {
                                    Icon(
                                        if (uiState.selectedTab == 2) Icons.Default.FolderOpen else Icons.Default.Folder,
                                        contentDescription = "Файлы"
                                    )
                                },
                                label = { Text("Файлы") },
                                modifier = Modifier.testTag("nav_tab_files")
                            )

                            NavigationBarItem(
                                selected = uiState.selectedTab == 3,
                                onClick = { viewModel.setSelectedTab(3) },
                                icon = {
                                    Icon(
                                        Icons.Default.PhoneAndroid,
                                        contentDescription = "Превью"
                                    )
                                },
                                label = { Text("Превью") },
                                modifier = Modifier.testTag("nav_tab_preview")
                            )
                        }
                    },
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (uiState.selectedTab) {
                            0 -> {
                                BuildScreen(
                                    currentPrompt = uiState.currentPrompt,
                                    onPromptChanged = { viewModel.setPrompt(it) },
                                    buildPhase = uiState.buildPhase,
                                    isBuilding = uiState.isBuilding,
                                    thinkingText = uiState.thinkingText,
                                    logs = uiState.logs,
                                    artifact = uiState.artifact,
                                    activeModel = uiState.activeModel,
                                    onStartBuild = { viewModel.startAutoBuild() },
                                    onClearLogs = { viewModel.clearLogs() },
                                    onDownloadApk = { viewModel.downloadApk() },
                                    onInstallApk = { installGeneratedApk() },
                                    onShareApk = { shareGeneratedApk() },
                                    onOpenPreview = { viewModel.setSelectedTab(3) },
                                    onOpenApiKeyDialog = { viewModel.openApiKeyDialog() }
                                )
                            }
                            1 -> {
                                BackHandler { viewModel.setSelectedTab(0) }
                                PythonEnvironmentScreen(
                                    pythonRuntime = viewModel.pythonRuntime,
                                    onApplyScriptToBuild = { scriptCode ->
                                        uiState.currentSpec?.let { spec ->
                                            viewModel.updateFileContent("scripts/build_pipeline.py", scriptCode)
                                            Toast.makeText(this@MainActivity, "Скрипт применен к сборщику", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                )
                            }
                            2 -> {
                                BackHandler { viewModel.setSelectedTab(0) }
                                ProjectFilesScreen(
                                    files = uiState.projectFiles,
                                    onFileContentChanged = { path, content ->
                                        viewModel.updateFileContent(path, content)
                                    }
                                )
                            }
                            3 -> {
                                BackHandler { viewModel.setSelectedTab(0) }
                                AppPreviewScreen(
                                    spec = uiState.currentSpec,
                                    onDownloadApk = { viewModel.downloadApk() },
                                    onBackToConsole = { viewModel.setSelectedTab(0) }
                                )
                            }
                        }

                        // Groq API Key Setup Dialog
                        if (uiState.isApiKeyDialogOpen) {
                            ApiKeyDialog(
                                currentApiKey = uiState.groqApiKey,
                                currentModel = uiState.activeModel,
                                onSave = { key, model ->
                                    viewModel.saveApiKey(key, model)
                                },
                                onDismiss = {
                                    viewModel.closeApiKeyDialog()
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    private fun installGeneratedApk() {
        val artifact = viewModel.uiState.value.artifact ?: return
        try {
            val intent = viewModel.apkBuilderEngine.createInstallIntent(artifact)
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось запустить установщик: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun shareGeneratedApk() {
        val artifact = viewModel.uiState.value.artifact ?: return
        try {
            val intent = viewModel.apkBuilderEngine.createShareIntent(artifact)
            startActivity(Intent.createChooser(intent, "Поделиться APK файлом"))
        } catch (e: Exception) {
            Toast.makeText(this, "Ошибка при отправке: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}
