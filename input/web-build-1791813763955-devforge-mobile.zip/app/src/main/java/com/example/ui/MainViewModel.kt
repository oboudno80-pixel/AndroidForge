package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.builder.ApkBuilderEngine
import com.example.data.*
import com.example.python.PythonRuntime
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class MainUiState(
    val currentPrompt: String = "Трекер привычек с таймером и статистикой",
    val buildPhase: BuildPhase = BuildPhase.IDLE,
    val isBuilding: Boolean = false,
    val thinkingText: String = "",
    val logs: List<BuildLog> = emptyList(),
    val currentSpec: GeneratedAppSpec? = null,
    val projectFiles: List<ProjectFile> = emptyList(),
    val artifact: ApkArtifact? = null,
    val selectedTab: Int = 0, // 0: Сборка, 1: Python, 2: Файлы, 3: Превью
    val isApiKeyDialogOpen: Boolean = false,
    val groqApiKey: String = "",
    val activeModel: String = "openai/gpt-oss-120b"
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    val preferencesManager = PreferencesManager(application)
    val pythonRuntime = PythonRuntime()
    val groqApiService = GroqApiService(preferencesManager)
    val apkBuilderEngine = ApkBuilderEngine(application, pythonRuntime)

    private val _uiState = MutableStateFlow(
        MainUiState(
            groqApiKey = preferencesManager.groqApiKey,
            activeModel = preferencesManager.modelName,
            isApiKeyDialogOpen = !preferencesManager.hasValidApiKey() && !preferencesManager.isFirstLaunchDone
        )
    )
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    private val _userMessage = MutableSharedFlow<String>()
    val userMessage: SharedFlow<String> = _userMessage.asSharedFlow()

    init {
        // Initialize default sample project structure
        initDefaultProjectFiles("Трекер привычек", "com.aistudio.habit.app")
    }

    fun setPrompt(prompt: String) {
        _uiState.update { it.copy(currentPrompt = prompt) }
    }

    fun setSelectedTab(tab: Int) {
        _uiState.update { it.copy(selectedTab = tab) }
    }

    fun openApiKeyDialog() {
        _uiState.update { it.copy(isApiKeyDialogOpen = true) }
    }

    fun closeApiKeyDialog() {
        preferencesManager.isFirstLaunchDone = true
        _uiState.update { it.copy(isApiKeyDialogOpen = false) }
    }

    fun saveApiKey(apiKey: String, model: String) {
        preferencesManager.groqApiKey = apiKey
        preferencesManager.modelName = model
        preferencesManager.isFirstLaunchDone = true
        _uiState.update {
            it.copy(
                groqApiKey = apiKey,
                activeModel = model,
                isApiKeyDialogOpen = false
            )
        }
        viewModelScope.launch {
            _userMessage.emit("Groq API Key успешно сохранен (модель: $model)")
        }
    }

    fun clearLogs() {
        _uiState.update { it.copy(logs = emptyList()) }
    }

    fun updateFileContent(path: String, newContent: String) {
        _uiState.update { state ->
            val updated = state.projectFiles.map {
                if (it.path == path) it.copy(content = newContent) else it
            }
            state.copy(projectFiles = updated)
        }
    }

    fun startAutoBuild() {
        val prompt = _uiState.value.currentPrompt.trim()
        if (prompt.isEmpty() || _uiState.value.isBuilding) return

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isBuilding = true,
                    buildPhase = BuildPhase.THINKING,
                    thinkingText = "Groq ($${preferencesManager.modelName}) анализирует идею '$prompt'..."
                )
            }

            addLog(BuildLogLevel.INFO, "Запуск процесса сборки приложения по запросу: \"$prompt\"")
            addLog(BuildLogLevel.THINKING, "Подключение к AI ядру (Groq gpt-oss-120b)...")

            // 1. Calling Groq or synthesized engine
            val result = groqApiService.generateAppArchitecture(prompt) { thinkingUpdate ->
                _uiState.update { it.copy(thinkingText = thinkingUpdate) }
                viewModelScope.launch { addLog(BuildLogLevel.THINKING, thinkingUpdate) }
            }

            val spec: GeneratedAppSpec = result.fold(
                onSuccess = { resp ->
                    _uiState.update { it.copy(thinkingText = resp.thinking) }
                    addLog(BuildLogLevel.SUCCESS, "AI успешно сформировал архитектуру проекта!")
                    resp.appSpec ?: createFallbackSpec(prompt)
                },
                onFailure = { error ->
                    addLog(BuildLogLevel.ERROR, "Предупреждение API: ${error.message}")
                    addLog(BuildLogLevel.INFO, "Используется встроенный локальный движок генерации шаблона...")
                    createFallbackSpec(prompt)
                }
            )

            _uiState.update { it.copy(currentSpec = spec) }
            updateProjectFilesFromSpec(spec)

            // 2. Running On-Device APK Builder Pipeline (Python -> Kotlin -> Gradle -> DEX -> APK)
            try {
                val artifact = apkBuilderEngine.runBuildPipeline(
                    spec = spec,
                    onLog = { level, msg -> addLog(level, msg) },
                    onPhaseChanged = { phase -> _uiState.update { it.copy(buildPhase = phase) } }
                )

                _uiState.update {
                    it.copy(
                        artifact = artifact,
                        isBuilding = false,
                        buildPhase = BuildPhase.READY
                    )
                }
                _userMessage.emit("APK успешно собран! Готов к скачиванию.")
            } catch (e: Exception) {
                addLog(BuildLogLevel.ERROR, "Ошибка при сборке: ${e.message}")
                _uiState.update {
                    it.copy(
                        isBuilding = false,
                        buildPhase = BuildPhase.ERROR
                    )
                }
                _userMessage.emit("Ошибка сборки: ${e.message}")
            }
        }
    }

    private suspend fun addLog(level: BuildLogLevel, message: String) {
        val newLog = BuildLog(level = level, message = message)
        _uiState.update { it.copy(logs = it.logs + newLog) }
    }

    fun downloadApk() {
        val art = _uiState.value.artifact ?: return
        val res = apkBuilderEngine.downloadApk(art)
        viewModelScope.launch {
            res.fold(
                onSuccess = { msg ->
                    addLog(BuildLogLevel.SUCCESS, msg)
                    _userMessage.emit(msg)
                },
                onFailure = { err ->
                    addLog(BuildLogLevel.ERROR, "Ошибка сохранения APK: ${err.message}")
                    _userMessage.emit("Ошибка: ${err.message}")
                }
            )
        }
    }

    private fun initDefaultProjectFiles(title: String, pkg: String) {
        val defaultSpec = createFallbackSpec(title)
        _uiState.update { it.copy(currentSpec = defaultSpec) }
        updateProjectFilesFromSpec(defaultSpec)
    }

    private fun updateProjectFilesFromSpec(spec: GeneratedAppSpec) {
        val files = listOf(
            ProjectFile(
                name = "MainActivity.kt",
                path = "app/src/main/java/${spec.packageName.replace('.', '/')}/MainActivity.kt",
                language = "kotlin",
                content = spec.mainKotlinCode
            ),
            ProjectFile(
                name = "build.gradle.kts",
                path = "app/build.gradle.kts",
                language = "gradle",
                content = spec.gradleCode
            ),
            ProjectFile(
                name = "build_pipeline.py",
                path = "scripts/build_pipeline.py",
                language = "python",
                content = spec.pythonScript
            ),
            ProjectFile(
                name = "AndroidManifest.xml",
                path = "app/src/main/AndroidManifest.xml",
                language = "xml",
                content = spec.manifestCode
            )
        )
        _uiState.update { it.copy(projectFiles = files) }
    }

    private fun createFallbackSpec(prompt: String): GeneratedAppSpec {
        val lower = prompt.lowercase()
        val uiType = when {
            lower.contains("калькулятор") || lower.contains("calc") -> "CALCULATOR"
            lower.contains("привычк") || lower.contains("habit") || lower.contains("трекер") -> "HABIT"
            lower.contains("звук") || lower.contains("музык") || lower.contains("synth") -> "SYNTH"
            lower.contains("заметк") || lower.contains("блокнот") || lower.contains("note") -> "NOTES"
            else -> "TODO"
        }

        val title = prompt.take(24).trim().ifBlank { "Mobile App" }
        val pkg = "com.aistudio.${title.replace("\\s+".toRegex(), "").lowercase()}.app"

        return GeneratedAppSpec(
            title = title,
            description = prompt,
            category = "Инструменты",
            packageName = pkg,
            uiType = uiType,
            features = listOf(
                "Чистый Material 3 интерфейс (Google guidelines)",
                "Автономная работа без сторонних серверов",
                "Python pre-build среда и Kotlin компиляция"
            ),
            mainKotlinCode = groqApiService.generateFallbackKotlin(title, uiType),
            pythonScript = groqApiService.generateDefaultPythonScript(title, pkg),
            gradleCode = groqApiService.generateDefaultGradleCode(pkg),
            manifestCode = groqApiService.generateDefaultManifest(pkg, title)
        )
    }
}
