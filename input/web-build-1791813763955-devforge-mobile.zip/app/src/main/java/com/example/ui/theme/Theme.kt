package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = M3BluePrimaryDark,
    onPrimary = M3BlueOnPrimaryDark,
    primaryContainer = M3BluePrimaryContainerDark,
    onPrimaryContainer = M3BlueOnPrimaryContainerDark,
    secondary = M3TealSecondaryDark,
    onSecondary = M3TealOnSecondaryDark,
    secondaryContainer = M3TealSecondaryContainerDark,
    onSecondaryContainer = M3TealOnSecondaryContainerDark,
    tertiary = M3CoralTertiaryDark,
    surface = M3SurfaceDark,
    surfaceVariant = M3SurfaceVariantDark,
    surfaceContainer = M3SurfaceContainerDark,
    surfaceContainerHigh = M3SurfaceContainerHighDark,
    outline = M3OutlineDark
)

private val LightColorScheme = lightColorScheme(
    primary = M3BluePrimaryLight,
    onPrimary = M3BlueOnPrimaryLight,
    primaryContainer = M3BluePrimaryContainerLight,
    onPrimaryContainer = M3BlueOnPrimaryContainerLight,
    secondary = M3TealSecondaryLight,
    onSecondary = M3TealOnSecondaryLight,
    secondaryContainer = M3TealSecondaryContainerLight,
    onSecondaryContainer = M3TealOnSecondaryContainerLight,
    tertiary = M3CoralTertiaryLight,
    surface = M3SurfaceLight,
    surfaceVariant = M3SurfaceVariantLight,
    surfaceContainer = M3SurfaceContainerLight,
    surfaceContainerHigh = M3SurfaceContainerHighLight,
    outline = M3OutlineLight
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
